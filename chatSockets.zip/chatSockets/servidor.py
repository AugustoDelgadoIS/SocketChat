import socket
import sys
import threading


class servidor():

    def __init__(self, host='127.0.0.1', port=3000):

        self.Clientes = []
        self.sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        self.sock.bind((str(host), int(port)))
        self.sock.listen(10)
        self.sock.setblocking(False)

        aceptar = threading.Thread(target=self.aceptaCon)
        procesar = threading.Thread(target=self.procesarCon)

        aceptar.daemon = True
        aceptar.start()

        procesar.daemon = True
        procesar.start()

        while True:
            msg = input('->')
            if msg == 'salir':
                self.sock.close()
                sys.exit()
            else:
                pass

    def msg_to_all(self, msg, cliente):
        for c in self.Clientes:
            try:
                if c != cliente:
                    c.send(msg)
            except:
                self.Clientes.remove(c)

    def aceptaCon(self):
        print("AceptarCon iniciado")

        while True:
            try:
                conn, addr = self.sock.accept()
                conn.setblocking(False)
                self.Clientes.append(conn)
            except:
                pass

    def procesarCon(self):
        print("ProcesarCon iniciado")

        while True:
            if len(self.Clientes) > 0:
                for c in self.Clientes:
                    try:
                        data = c.recv(1024)
                        if data:
                            self.msg_to_all(data, c)
                    except:
                        pass


s = servidor()
